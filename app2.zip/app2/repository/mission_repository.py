from app2.db.database import session_maker
from app2.db.models.mission import Mission


def get_mission_by_id(m_id):
    with session_maker() as session:
        mission = session.get(Mission, m_id)
        return mission

def get_missions_between_days(start, end):
    with session_maker() as session:
        return session.query(Mission).filter((Mission.mission_date > start) & (Mission.mission_date < end)).all()

def get_mission_by_country(country_name):
    with session_maker() as session:
        missions = session.query(Mission).filter(Mission.target.city.country == country_name).all()
        return missions

def get_mission_by_target_industry(target_industry):
    with session_maker() as session:
        missions = session.query(Mission).filter(Mission.targets.target_industry == target_industry).all()
        return missions

def get_result_attack_by_target_type(target_type):
    with session_maker() as session:
        res = session.query(Mission).filter(Mission.targets.target_type == target_type).all()
        return res
