from graphene import ObjectType, List, Date
from app2.gql.types.mission_type import MissionType
from app2.repository.mission_repository import get_missions_between_days


class Query(ObjectType):
    missions_between_days = List(MissionType, start=Date(), end=Date())


    @staticmethod
    def resolve_missions_between_days(root, info, start, end):
        return get_missions_between_days(start, end)
